#Prefabparser by Patrick Busch 2019
#coding: utf-8
import string
import sys
import re
import os
import struct
import tkinter as tk
from tkinter import ttk
from tkinter.ttk import Progressbar
from tkinter import messagebox, filedialog

path = os.getcwd()
path = os.path.abspath('..')

zoning				= re.compile(r'<property\s?name="Zoning"\s?value=".*"\s?/>')
rotationtofacenorth	= re.compile(r'<property\s?name="RotationToFaceNorth"\s?value=".*"\s?/>')
yoffset				= re.compile(r'<property\s?name="YOffset"\s?value=".*"\s?/>')
allowedtownships	= re.compile(r'<property\s?name="AllowedTownships"\s?value=".*"\s?/>')

class Parser(object):
	def __init__(self,master):
		self._master = master
		self._master.resizable(0,0)

		self._master.title("Prefabparser by Patrick Busch")
		self.prefabsfolder = tk.StringVar()
		self.progress = tk.StringVar()
		self.status = tk.StringVar()
		self._directory = ""

		self._files = []
		self.bt_openfolder = tk.Button(text= "Locate Prefabsfolder...",command=self.getprefabsfolder)
		self.bt_openfolder.pack(side=tk.TOP,fill=tk.BOTH,padx=3,pady=3)

		self.lb_selected_folder = tk.Label(self._master,text="",textvariable=self.prefabsfolder,relief=tk.SUNKEN)
		self.lb_selected_folder.pack(side=tk.TOP,fill=tk.X,padx=3,pady=3)

		self.bt_parse = tk.Button(self._master,text="Collect and parse Prefabs",command=self.parse)
		self.bt_parse.pack(side=tk.TOP,fill=tk.X,padx=3,pady=3)

		self.progress = Progressbar(self._master, length=400, mode="determinate")
		self.progress.pack(side=tk.TOP, padx=3, pady=3)

		self.lb_status = tk.Label(
			self._master, text="waiting...", relief=tk.SUNKEN, textvariable=self.status, anchor=tk.W, bd=2
        )
		self.lb_status.pack(side=tk.BOTTOM, fill=tk.X)


	def getprefabsfolder(self):
		"""	ask for the folder where the prefabs including the 'tts' and 'xml' files reside
			both of which are needed for the parsing
		"""
		current_dir = os.path.dirname(__file__)
		self._directory = filedialog.askdirectory(
				initialdir=current_dir,
				title="Select '7 Days To Die/Data/Prefabs' folder please"
			)
		if self._directory:
			self.prefabsfolder.set(self._directory)
			if self._directory.endswith('Prefabs'):
				self._files = os.listdir(self._directory)
				#check if prefabfiles come in pairs .. as should be
				ttscounter = 0
				xmlcounter = 0
				for file in self._files:
					if file.endswith('tts'):
						ttscounter += 1
					if file.endswith('xml'):
						xmlcounter += 1
				if ttscounter != xmlcounter:
					messagebox.showwarning("Open '7 Days To Die/data/Prefabs' folder..",f"There seem to be:\n{ttscounter} tts files and\n{xmlcounter} xml files.\nThose numbers should be equal!\nPrefabs that miss either file will be skipped!\nSkipped files will be listed at the end.")
				return
			else:
				messagebox.showwarning("Open '7 Days To Die/data/Prefabs' folder..",f"This may not be the right folder, {self._directory}")
				return

	def parse(self):
		ttscounter = 0
		xmlcounter = 0
		skipped = []
		with open("prefablist.txt","w") as outfile:
			progressstate = 0  # start with 0 progress
			for file in self._files:
				progressstate += 1  # update the state of progress
				progressact = int(progressstate / len(self._files) * 100)

				filename = file.split('.')
				if filename[1] == "tts":
					#if there is a 'tts' file, there must be a same name 'xml' file!
					if (filename[0] + '.xml') not in self._files:
						skipped.append(filename[0]+'.xml')
						self.status.set(f"!{filename[0]}.xml could not be found!")
						continue
					zoneinfo = "NONE"
					rotationinfo = "0"
					yoffsetinfo = "0"
					placement = ""
					with open(self._directory+'\\'+filename[0]+".xml") as xmlfile:
						xmlcounter+=1
						xmllines = xmlfile.readlines()
						for line in xmllines:
							zone = zoning.search(line)
							if zone:
								zoneinfo = zone.group().split('"')[3].replace(",",";")

							rotation = rotationtofacenorth.search(line)
							if rotation:
								rotationinfo = rotation.group().split('"')[3]

							yoff = yoffset.search(line)
							if yoff:
								yoffsetinfo = yoff.group().split('"')[3]

							townships = allowedtownships.search(line)
							if townships:
								placement = townships.group().split('"')[3].replace(",",";")
								placement = placement.replace("city","citycenter")
								placement = placement.replace("town","downtown")
								placement = placement.replace("rural","smalltown")
								placement = placement.replace("wilderness","alone")
								placement = placement.replace("residentialnew","houses")
								placement = placement.replace("residentialold","houses")
								placement = placement.replace("residential","houses")
					with open(self._directory+'\\'+file,'rb') as ttsfile:
						ttscounter+=1
						#skip the header 'tts ' and version info
						ttsfile.read(8)
						# go straight to the size info
						_x = str(struct.unpack('H', ttsfile.read(2)))
						_y = str(struct.unpack('H', ttsfile.read(2)))
						_z = str(struct.unpack('H', ttsfile.read(2)))

						#name,ZONING,ROTATIONTOFACENORTH,YOFFSET,X,Y,Z,PLACEMENT
						result = (filename[0]+","+zoneinfo+","+rotationinfo+","+yoffsetinfo+",")+(_x+_y+_z).replace('(','').replace(')','')+placement
						if placement == "":
							result = result+"none"
					#print(result)
					outfile.write(result+" \n")
				self.status.set(f"Parsing Prefab file: {progressact} %")
				self.progress["value"] = progressact
				self._master.update()
			if skipped:
				joined = ', '.join(skipped)
				self.status.set(f"Skipped {len(skipped)} files!")
				messagebox.showinfo("Skipped|Not found files:",f"{joined}")
			else:
				self.status.set(f"{ttscounter} '.tts' & {xmlcounter} '.xml' files parsed! Thanks for your patience")


root = tk.Tk()
Parser(root)

print('Prefabparser ©by Patrick Busch\nTool to lighten the work creating Prefablists.\nGenerated "Prefabslist.txt" will be saved in the parserdirectory.\nManual correction and editing will be needed for usage with NITROGEN!\n')
#Warranty statement
print('THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\nIMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\nFITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\nAUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\nLIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\nOUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\nSOFTWARE.')
root.mainloop()